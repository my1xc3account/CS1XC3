/**
 * @mainpage Book function demonstration
 *  
 * The course function demonstration shows how multiple functions in the course 
 * library work, including:
 * - enrolling a student
 * - printing the course
 * - printing students
 * - finding the top student
 * - finding the total number of passing students
 * - finding the names of the students that are passing
 * 
 * @file main.c
 * @author Haley Johnson
 * @date 2022-04-08
 * @brief Runs demonstration code for course library methods.
 *
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * Creates a class list represented as an array, and tests the course 
 * library methods for enrolling students, printing the course, printing the students,
 * getting the top student in the class, getting the total passing in the class, and
 * getting the names of the students who are passing the class
 * 
 */
int main()
{
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}