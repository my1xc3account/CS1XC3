/**
 * @file course.c
 * @author Haley Johnson
 * @date 2022-04-08
 * @brief Course library for managing the course, including definition of Course
 *        function.
 *
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/** 
 * Enrolls a student into a course
 * 
 * @param course a pointer to the course info that is declared to a struct
 * @param student a pointer to the student info that is declared to a struct
 * @return nothing
 */ 
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    //allocating space on the heap for 1 student if the
    //total number of students in a course is equal to 1
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    //otherwise re-allocating a larger block of memory of the 
    //appropriate size to the course->students pointer
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  //adding the student to the list of total students in the course
  course->students[course->total_students - 1] = *student;
}

/** 
 * Prints the course in a list including name, code, total students enrolled
 * 
 * @param course a pointer that is declared to a struct
 * @return nothing
 */ 
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/** 
 * Returns the student with the highest average in the course using linear traversal
 * 
 * @param course a pointer that is declared to a struct
 * @return Student* which is a pointer to the student with the highest average
 */ 
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
//traversing through the total students in the course to find the student with max average
//using linear traversal 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}
/** 
 * Returns an array of students with an average higher than 50% in the course
 * 
 * @param course a pointer that is declared to a struct
 * @param total_passing a pointer that is declared to an int
 * @return passing which is the dynamic array of students with an average higher  
 * than 50% in the course
 */ 
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;

  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;

  //Allocating memory in the heap using calloc for the number of students with an average
  //higher than 50% and assigning this to an array called passing 
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      //Adding the students that are passing the course to the array
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}