/**
 * @file course.h
 * @author Haley Johnson
 * @date 2022-04-08
 * @brief Course library for managing courses, including definition of Course
 *        function.
 *
 */
#include "student.h"
#include <stdbool.h>
 /**
 * Using typedef with structure to define _course and the type name of _course named Course,
 * along with members course name, course code, students, and total number of students
 *
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;
//declaring the functions
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


