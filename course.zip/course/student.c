/**
 * @file student.c
 * @author Haley Johnson
 * @date 2022-04-08
 * @brief Student library for managing the students, including definition of Student
 *        function.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * Adds a students grade in the course to the students information
 *
 * @param student a pointer to the students grade info that is declared to a struct
 * @param grade the grade a student has in the course with type double 
 * @return nothing
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  //allocating space on the heap for 1 students grade with the appropriate size double
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    student->grades = 
      //re-allocating a larger block of memory of the appropriate size to the student->grades pointer
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * Returns the average that a student has in the course
 *
 * @param student a pointer to the students grade info that is declared to a struct
 * @return the average that the given student has achieved in the course, with type double
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  //using total to add up all the grades the student achieved has in the class
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  //dividing the total number of grades by the number of assessments
  return total / ((double) student->num_grades);
}

/**
 * Printing the students information including name, ID, grades, and average
 *
 * @param student a pointer to the students grade info that is declared to a struct
 * @return nothing
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * Generates a random student and their grade information
 *
 * @param grade the students number of grades with type int
 * @return Student* which points to the newly generated student
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};

  //allocating space on the heap for 1 student with the appropriate size
  Student *new_student = calloc(1, sizeof(Student));
  //using rand to generate a random number corresponding to the names in the array and using
  //it as the index to get a random name combination
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  //using rand to get a random student id 
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  for (int i = 0; i < grades; i++) 
  { 
    //using rand to get a random grade using the number of grades in the parameter
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}