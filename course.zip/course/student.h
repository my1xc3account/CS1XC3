/**
 * @file student.h
 * @author Haley Johnson
 * @date 2022-04-08
 * @brief Student library for managing the students, including definition of Student
 *        function.
 *
 */

 /**
 * Using typedef with structure to define _student and the type name of _course named Student,
 * along with members first name, last code, student id, grades, and total number of grades
 *
 */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

//declaring functions
void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
